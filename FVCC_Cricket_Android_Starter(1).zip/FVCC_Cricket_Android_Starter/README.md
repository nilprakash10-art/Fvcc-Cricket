# FVCC Cricket Android Starter

This is an early Flutter starter prototype for Fortview Cricket Club.

## Build APK using GitHub Actions from an Android phone

1. Create a new **public or private** GitHub repository named `fvcc-cricket`.
2. Upload the contents of this ZIP to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. If prompted, enable GitHub Actions.
5. Open **Build FVCC Android APK** and tap **Run workflow** (or push to `main` to trigger it).
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run and download the `FVCC-Cricket-Android-APK` artifact.
8. Extract the downloaded artifact ZIP; it contains `app-release.apk`.

## Important

This is only a starter UI. It does not yet implement real authentication, database storage,
scoring, player registration, tournament logic, or the agreed four-admin/scorer approval system.
Those features need to be developed and tested before club use.

The original club logo was not included in this package because no actual image file was available
in the current workspace. Add the approved logo later under `assets/` and configure it in Flutter.
