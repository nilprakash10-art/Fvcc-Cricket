import 'package:flutter/material.dart';

void main() => runApp(const FvccApp());

class FvccApp extends StatelessWidget {
  const FvccApp({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF1456A0);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FVCC Cricket',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: navy),
        scaffoldBackgroundColor: const Color(0xFFF5F8FC),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1456A0),
        foregroundColor: Colors.white,
        title: const Text('FVCC CRICKET'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 18),
          CircleAvatar(
            radius: 42,
            backgroundColor: const Color(0xFF1456A0),
            child: const Text('FVCC',
                style: TextStyle(color: Colors.white, fontSize: 24,
                    fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 16),
          const Text('Fortview Cricket Club',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Your club. Your game. Your score.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 28),
          _tile(context, Icons.admin_panel_settings, 'Admin Login',
              'Admin access and club management'),
          _tile(context, Icons.sports_cricket, 'Scorer Login',
              'Scorer access (admin approval required)'),
          _tile(context, Icons.groups, 'Players & Teams',
              'Player registration and team management'),
          _tile(context, Icons.scoreboard, 'Live Scoring',
              'Leather-ball and tennis-ball cricket'),
          _tile(context, Icons.emoji_events, 'Tournaments',
              'Fixtures, standings and tournament management'),
          const SizedBox(height: 20),
          const Text('Starter prototype • Account and scoring services are not connected yet.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: Colors.black54)),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String title, String subtitle) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF1456A0), size: 30),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$title will be added in a later development phase.')),
        ),
      ),
    );
  }
}
